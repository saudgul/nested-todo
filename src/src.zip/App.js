
import Nested from './component/nestedlist';

import './App.css';

function App() {
  return (
    <div className="App">
      <Nested/>
    
      
     
      
      
    </div>
  );
}

export default App;
